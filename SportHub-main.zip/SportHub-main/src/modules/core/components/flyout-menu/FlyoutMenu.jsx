const FlyoutMenu = () => {
    return (
        <div className="fixed">

        </div>
    )
}

export default FlyoutMenu