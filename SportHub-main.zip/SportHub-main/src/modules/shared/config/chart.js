const config = {
    type: 'line',
    options: {
        responsive: true,
        maintainAspectRatio: false,
    }

}
export default config