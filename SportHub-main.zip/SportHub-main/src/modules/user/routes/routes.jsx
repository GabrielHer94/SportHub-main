import Login from "../pages/Login"

const routes = [
    {
        path : '/',
        element: <Login/>
    }
]

export default routes